<?php

ini_set("assert.exception", 1);
assert(true == false, "Expected true to be false");
